import styles from './card.module.scss'
import * as AiIcons from "react-icons/ai";
import {useNavigate} from 'react-router-dom'
import {setBranchId} from "../../redux/actions/optionActions";
import {useDispatch} from "react-redux";
import rateIcon from './rate.svg'

const ItemInSlider = ({product, best}) => {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const handleClickCard = async () => {

        if (best) {
            navigate(`/product_market/${product.id}`)

        } else {
            await localStorage.setItem("branch_id", product?.pivot?.product_id)
            await dispatch(setBranchId(product?.pivot?.product_id))
            navigate(`/product_details/${product.id}`)
        }
    }
    return (
        <div onClick={() => handleClickCard()} className={styles.wrapper}>
            <div className={styles.container}>
                <div className={styles.top}>
                    <img src={product.image} alt=""/>
                </div>
                <div className={styles.bottom}>
                    <div className={styles.details}>
                        <div className={styles.container_name}>
                            <p>{product.name}</p>
                        </div>
                        <div className={styles.container_rate}>
                            <p>{product.rate_avg}</p>
                            <img src={rateIcon} alt=""/>
                        </div>
                    </div>
                    <div className={styles.buy2}>
                        < AiIcons.AiOutlineShoppingCart className={styles.icon}/>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default ItemInSlider