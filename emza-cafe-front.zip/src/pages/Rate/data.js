import imgSilver from './silver.svg'
import imgBoronz from './boronz.svg'
import imgGold from './gold.svg'

export const dataRate = [
    {id: 0, rank_id: 1, img: imgBoronz, title: 'سطح برنزی'},
    {id: 1, rank_id: 2, img: imgSilver, title: 'سطح نقره ای'},
    {id: 2, rank_id: 3, img: imgGold, title: 'سطح طلایی'},
]